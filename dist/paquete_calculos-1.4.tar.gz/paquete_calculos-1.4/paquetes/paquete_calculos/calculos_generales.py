def sumar(op1,op2):
    print(op1," + ",op2,"=",op1+op2)

def restar(op1,op2):
    print(op1," - ",op2,"=",op1-op2)

def multiplicar(op1,op2):
    print(op1," * ",op2,"=",op1*op2)

def dividir(op1,op2):
    print(op1," / ",op2,"=",op1/op2)

def potenciar(base,exponente):
    print(base," ^ ",exponente,"=",base**exponente)

def redondear(numero):
    print(numero," ~ ",round(numero))
